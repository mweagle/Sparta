// Convenience file to require the SDK from the root of the repository
module.exports = require('./lib/aws');
